package healthcaregui;

public class HealthCareGUI {
    public static void main(String[] args) {
        new LoginForm().setVisible(true);
    }
}
